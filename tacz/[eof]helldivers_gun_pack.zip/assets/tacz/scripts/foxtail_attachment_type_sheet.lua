local MODULE = {}
MODULE.GRIP = {}

MODULE.GRIP["VG"] = { --定义VG类型握把 垂直握把
    "tacz:grip_rk0",
    "tacz:grip_vertical_ranger",
    "tacz:grip_vertical_military",
    "tacz:grip_vertical_talon",
    "tacz:grip_osovets_black"
}
MODULE.GRIP["AFG"] = { --定义AFG类型握把 三角前握把
    "tacz:grip_magpul_afg_2",
    "tacz:grip_cobra"
}
MODULE.GRIP["A45DFG"] = { --定义A45DFG类型握把 45度偏心握把
    "tacz:grip_rk1_b25u"
}

return MODULE