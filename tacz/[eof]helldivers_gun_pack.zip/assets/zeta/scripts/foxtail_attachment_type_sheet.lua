local MODULE = {}
MODULE.GRIP = {}

MODULE.GRIP["VG"] = { --定义VG类型握把 垂直握把
    "zeta:grip_exp"
}

return MODULE